killall xsettingsd

# Colors GTK Pywal
rm -rf .themes/oomox-Pywal
cp -r ~/.themes/oomox-PywalAux ~/.themes/oomox-Pywal

cd ~/.themes/oomox-Pywal && replacement=$(sed -n '1p' ~/.cache/wal/colors)
cd ~/.themes/oomox-Pywal && sed -i "s/#000000/$replacement/g" $(grep -rl '#000000' .)

cd ~/.themes/oomox-Pywal && replacement=$(sed -n '5p' ~/.cache/wal/colors)
cd ~/.themes/oomox-Pywal && sed -i "s/#040404/$replacement/g" $(grep -rl '#040404' .)

cd ~/.themes/oomox-Pywal && replacement=$(sed -n '10p' ~/.cache/wal/colors)
cd ~/.themes/oomox-Pywal && sed -i "s/#090909/$replacement/g" $(grep -rl '#090909' .)

cd ~/.themes/oomox-Pywal && replacement=$(sed -n '13p' ~/.cache/wal/colors)
cd ~/.themes/oomox-Pywal && sed -i "s/#121212/$replacement/g" $(grep -rl '#121212' .)

cd ~/.themes/oomox-Pywal && replacement=$(sed -n '16p' ~/.cache/wal/colors)
cd ~/.themes/oomox-Pywal && sed -i "s/#151515/$replacement/g" $(grep -rl '#151515' .)

# Colors Icons Pywal
rm -rf ~/.icons/oomox-Pywal
cp -r ~/.icons/oomox-PywalAux ~/.icons/oomox-Pywal

cd ~/.icons/oomox-Pywal && replacement=$(sed -n '10p' ~/.cache/wal/colors)
cd ~/.icons/oomox-Pywal && sed -i "s/#090909/$replacement/g" $(grep -rl '#090909' .)

# gtk3 theme
sed -i '2s/.*/gtk-theme-name=oomox-Pywal/' ~/.config/gtk-3.0/settings.ini
sed -i '3s/.*/gtk-icon-theme-name=oomox-Pywal/' ~/.config/gtk-3.0/settings.ini

# xsettingsd
sed -i '1s/.*/Net\/ThemeName "oomox-Pywal"/' ~/.xsettingsd
sed -i '2s/.*/Net\/IconThemeName "oomox-Pywal"/' ~/.xsettingsd

# gtk2 and qt theme
sed -i '1s~.*~include "/home/mike/.themes/oomox-Pywal/gtk-2.0/gtkrc"~' ~/.gtkrc-2.0
sed -i '2s/.*/gtk-icon-theme-name = "oomox-Pywal"/' ~/.gtkrc-2.0
sed -i '3s/.*/gtk-font-name="Hurmit Nerd Font Light 9"/' ~/.gtkrc-2.0

sed -i '1s~.*~include "/home/mike/.themes/oomox-Pywal/gtk-2.0/gtkrc"~' ~/.gtkrc.mine
sed -i '2s/.*/gtk-icon-theme-name = "oomox-Pywal"/' ~/.gtkrc.mine
sed -i '3s/.*/gtk-font-name="Hurmit Nerd Font Light 9"/' ~/.gtkrc.mine


sed -i '4s/.*/icon_theme=oomox-Pywal/' ~/.config/qt6ct/qt6ct.conf
sed -i '4s/.*/icon_theme=oomox-Pywal/' ~/.config/qt5ct/qt5ct.conf

sleep 1
# Reload GTK theme
xsettingsd &
sleep 1
killall xsettingsd

# pywal change theme
wal --theme Pywal
~/.config/bspwm/colors.sh

# walogram (telegram theme)
walogram -s

# nitrogen Wallpaper
#cd "$(xdg-user-dir PICTURES)" && nitrogen --random --set-scaled Wallpapers/Pywal
#echo "cd "$(xdg-user-dir PICTURES)" && nitrogen --random --set-scaled Wallpapers/Pywal" >> ~/.config/bspwm/wallpaper.sh

# ly Display Manager colors
cp ~/.cache/wal/ly.service /lib/systemd/system/ly.service
